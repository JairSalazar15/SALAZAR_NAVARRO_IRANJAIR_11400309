package tdm2018.ittepic.edu.tdm2018_u1_reciclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<PersonajeVo> listaPersonajes;
    RecyclerView recyclerPersonajes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        construirRecycler();

    }

    private void llenarPersonajes() {
        listaPersonajes.add(new PersonajeVo("Krusty","conocido como Krusty el payaso.",R.drawable.krusti));
        listaPersonajes.add(new PersonajeVo("Homero","Protagonistas de la serie. Es el padre de la familia.",R.drawable.homero));
        listaPersonajes.add(new PersonajeVo("Marge","Marjorie \"Marge\"Una de los protagonistas de la serie. ",R.drawable.marge));
        listaPersonajes.add(new PersonajeVo("Bart","Bartholomew JoJo «Bart» Simpson, es uno de los protagonistas de la serie. ",R.drawable.bart));
        listaPersonajes.add(new PersonajeVo("Lisa","Lisa Marie Simpson es una de las protagonistas de la serie.",R.drawable.lisa));
        listaPersonajes.add(new PersonajeVo("Magie","Margaret Evelyn \"Maggie\" Simpson es una de las protagonistas de la serie.",R.drawable.magie));
        listaPersonajes.add(new PersonajeVo("Flanders","Nedward «Ned» Flanders es un besino de los simpson.",R.drawable.flanders));
        listaPersonajes.add(new PersonajeVo("Milhouse","Milhouse Mussolini Van Houten es un personaje en la serie.",R.drawable.milhouse));
        listaPersonajes.add(new PersonajeVo("Mr. Burns","Charles Montgomery Burns, más conocido como el señor Burns o Monty Burns.",R.drawable.burns));
    }

    public void onClick(View view) {


        switch (view.getId()){
            case R.id.btnList: Utilidades.visualizacion=Utilidades.LIST;
                break;
            case R.id.btnGrid: Utilidades.visualizacion=Utilidades.GRID;
                break;
        }

        construirRecycler();
    }

    private void construirRecycler() {
        listaPersonajes=new ArrayList<>();
        recyclerPersonajes= (RecyclerView) findViewById(R.id.RecyclerId);

        if (Utilidades.visualizacion==Utilidades.LIST){
            recyclerPersonajes.setLayoutManager(new LinearLayoutManager(this));
        }else {
            recyclerPersonajes.setLayoutManager(new GridLayoutManager(this,3));
        }

        llenarPersonajes();

        AdaptadorPersonajes adapter=new AdaptadorPersonajes(listaPersonajes);

        adapter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),
                        "Selección: "+listaPersonajes.get
                                (recyclerPersonajes.getChildAdapterPosition(view))
                                .getNombre(), Toast.LENGTH_SHORT).show();
            }
        });

        recyclerPersonajes.setAdapter(adapter);
    }
}
