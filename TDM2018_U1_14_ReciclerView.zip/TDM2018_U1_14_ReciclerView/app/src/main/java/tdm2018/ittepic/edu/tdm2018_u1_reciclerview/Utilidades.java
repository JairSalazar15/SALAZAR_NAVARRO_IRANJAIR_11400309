package tdm2018.ittepic.edu.tdm2018_u1_reciclerview;

/**
 * Created by Jair on 13/02/2018.
 */

public class Utilidades {
    public static final int LIST=1;
    public static final int GRID=2;

    public static int visualizacion=LIST;
}
