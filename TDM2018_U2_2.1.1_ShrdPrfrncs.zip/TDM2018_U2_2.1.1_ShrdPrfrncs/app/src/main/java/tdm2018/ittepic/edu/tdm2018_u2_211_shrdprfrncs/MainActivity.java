package tdm2018.ittepic.edu.tdm2018_u2_211_shrdprfrncs;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, AdapterView.OnItemSelectedListener {
    private String email;
    private String genero;
    private String hobbies;
    private String signo;

    public static final String STORAGE_NAME = "MySharedPreferences";        ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = ((EditText)findViewById(R.id.editTextMail)).getText().toString();;
        genero = "";
        hobbies = "";
        signo = "";

        RadioGroup radioGroupGender = (RadioGroup) findViewById(R.id.radioGroupGender);
        radioGroupGender.setOnCheckedChangeListener(this);

        Spinner spinnerZodiac = (Spinner) findViewById(R.id.signos_array);
        // Populate the spinner with data source
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.signos_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerZodiac.setAdapter(adapter);

        spinnerZodiac.setOnItemSelectedListener(this);

        // Add other code
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        int radioButtonId = radioGroup.getCheckedRadioButtonId();
        RadioButton radioButton = (RadioButton)radioGroup.findViewById(radioButtonId);
        genero = radioButton.getText().toString();
    }
    // Add other methods

    public void onCheckboxClicked(View view) {

        CheckBox chkJogging = (CheckBox) findViewById(R.id.checkBoxArt);
        CheckBox chkCoding = (CheckBox) findViewById(R.id.checkBoxCult);
        CheckBox chkWriting = (CheckBox) findViewById(R.id.checkDep);

        StringBuilder sb = new StringBuilder();

        if (chkJogging.isChecked()) {
            sb.append(", " + chkJogging.getText());
        }

        if (chkCoding.isChecked()) {
            sb.append(", " + chkCoding.getText());
        }

        if (chkWriting.isChecked()) {
            sb.append(", " + chkWriting.getText());
        }

        if (sb.length() > 0) { // No toast if the string is empty
            // Remove the first comma
            hobbies = sb.deleteCharAt(sb.indexOf(",")).toString();
        } else {
            hobbies = "";
        }
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        signo = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public void save(View view) {
        // Capture email input
        email = ((EditText)findViewById(R.id.editTextMail)).getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences(STORAGE_NAME, Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", email);
        editor.putString("gender", genero);
        editor.putString("hobbies", hobbies);
        editor.putString("zodiac", signo);

        editor.apply();

        Toast.makeText(getApplicationContext(), "Datos Guardados", Toast.LENGTH_SHORT).show();

        // To add code to save data to storage later on
    }

    public void retrieve(View view) {
        SharedPreferences sharedPreferences = getSharedPreferences(STORAGE_NAME, Context.MODE_PRIVATE);

        email = sharedPreferences.getString("email", "");
        genero = sharedPreferences.getString("gender", "");
        hobbies = sharedPreferences.getString("hobbies", "");
        signo = sharedPreferences.getString("zodiac", "");

        setupUI();
    }

    protected void setupUI(){
        ((EditText)findViewById(R.id.editTextMail)).setText(email); // Add code here

        RadioButton radMale = (RadioButton)findViewById(R.id.radioButtonM);
        RadioButton radFemale = (RadioButton)findViewById(R.id.radioButtonF);

        if (genero.equals("Masculino")){
            radMale.setChecked(true);
        } else if (genero.equals("Femenino")){
            radFemale.setChecked(true);
        } else {
            radMale.setChecked(false);
            radFemale.setChecked(false);
        }

        CheckBox chkCoding = (CheckBox)findViewById(R.id.checkDep);
        CheckBox chkWriting = (CheckBox)findViewById(R.id.checkBoxCult);
        CheckBox chkJogging = (CheckBox)findViewById(R.id.checkBoxArt);

        chkCoding.setChecked(false);
        chkWriting.setChecked(false);
        chkJogging.setChecked(false);

        if (hobbies.contains("Cantar")) {
            chkCoding.setChecked(true);
        }

        if (hobbies.contains("Practicar Deporte")) {
            chkWriting.setChecked(true);
        }

        if (hobbies.contains("Cine")) {
            chkJogging.setChecked(true);
        }


        Resources resource = getResources();
        String[] zodiacArray = resource.getStringArray(R.array.signos);
        for(int i = 0; i < zodiacArray.length; i++){
            if(zodiacArray[i].equals(signo)){
                ((Spinner)findViewById(R.id.signos_array)).setSelection(i);
            }
        }
    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}
