package tdm2018.ittepic.edu.tdm2018_u2_223_lab1_cursor_recilerview;

import android.content.Context;
import android.content.Intent;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Jair on 27/02/2018.
 */

public class ConDB extends SQLiteOpenHelper{
    private static final String NOMBRE_BD= "cancones.db";
    private static final int VERSION_BD=1;
    private static final String TABLA_CANCIONES="CREATE TABLE CANCIONES(INT ID AUTOINCREMENT, NOMBRE TEXT PRIMARY KEY, GENERO TEXT  )";

    public ConDB(Context context) {
        super(context, NOMBRE_BD, null,VERSION_BD);

    }

    @Override
    public void onCreate(SQLiteDatabase sqL) {
        sqL.execSQL(TABLA_CANCIONES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqL, int i, int i1) {
        sqL.execSQL(TABLA_CANCIONES);
        //sqL.execSQL(TABLA_CANCIONES);

    }
    public void agregarCancion(String nombre, String genero){
        SQLiteDatabase db=getWritableDatabase();
        if(db !=null){ //verificamos si se abrio correctamente la BD
            db.execSQL("INSERT INTO CANCIONES VALUES('"+nombre+"','"+genero+"')");
            db.close();

        }

    }
}
