package tdm2018.ittepic.edu.tdm2018_u2_223_lab1_cursor_recilerview;

import android.graphics.drawable.Drawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Jair on 04/03/2018.
 */

public class ReciclerAdapter extends RecyclerView.Adapter<ReciclerAdapter.ViewHolder> {

    public class ViewHolder extends RecyclerView.ViewHolder {
         private TextView nombre, cntrl;
        private ImageView foto;

        public ViewHolder(View itemView) {
            super(itemView);
            nombre=(TextView)itemView.findViewById(R.id.textViewNombre);
            cntrl=(TextView)itemView.findViewById(R.id.textViewNoctrl);
            foto=(ImageView)itemView.findViewById(R.id.imageView);

        }
    }
    public List<DatoContacto> listaContacto; //Almacenamos los datos en caa item

    //El constructor recibe como parametro la lista creada
    public ReciclerAdapter(List<DatoContacto> listaContacto) {
        this.listaContacto = listaContacto;
    }

    //metodo encargado de inflar el contenido de un iten nuevo para la lista
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.card,parent,false);
        ViewHolder viewHolder=new ViewHolder(view);
        return viewHolder;
    }




   //metodo encargado de modificar el contenido de ada item
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.nombre.setText(listaContacto.get(position).getNombre());
        holder.cntrl.setText(listaContacto.get(position).getNoctrl());
        holder.foto.setImageResource(listaContacto.get(position).getImagen());


    }

    @Override
    public int getItemCount() {
        return listaContacto.size();
    }
}
