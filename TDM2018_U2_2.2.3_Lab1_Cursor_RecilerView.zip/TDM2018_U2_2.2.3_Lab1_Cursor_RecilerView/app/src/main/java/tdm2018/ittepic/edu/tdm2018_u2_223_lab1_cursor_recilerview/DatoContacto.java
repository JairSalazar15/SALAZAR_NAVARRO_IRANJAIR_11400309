package tdm2018.ittepic.edu.tdm2018_u2_223_lab1_cursor_recilerview;

import android.widget.ImageView;

import java.util.ArrayList;

/**
 * Created by Jair on 01/03/2018.
 */

public class DatoContacto {

    private String nombre;
    private String noctrl;
    private static int ultimo=0;
    public int imagen;

    public DatoContacto(String nombre, boolean estatus) {
        this.nombre = nombre;
        this.noctrl=noctrl;
        this.imagen=imagen;

    }

    public DatoContacto(String nombre, String noctrl, int imagen) {
    }

    public String getNombre(){
        return nombre;
    }

    public String getNoctrl(){return noctrl;}

    public int getImagen(){return imagen;}




}
