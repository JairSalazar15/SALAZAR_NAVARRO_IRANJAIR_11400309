package tdm2018.ittepic.edu.tdm2018_u2_223_lab1_cursor_recilerview;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    //instacias RecyclerView y RecyclerAdapter
    private  RecyclerView rv;
    private ReciclerAdapter adaptadoralumno;

    Button add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //vinculo de la instancia rv con el objeto recycLer_view dentro de nuestro laout
        rv = (RecyclerView) findViewById(R.id.recycler_view);
        //definicion de la forma de la lista en este caso vertical
        rv.setLayoutManager(new LinearLayoutManager(this));

        //enviamos toda la informacion agregada a la lista
        adaptadoralumno=new ReciclerAdapter(obtenerContacto());
        //asignamos toda la informacion al objeto recyclerView de nuestro laout
        rv.setAdapter(adaptadoralumno);

        add = (Button) findViewById(R.id.btnADD);


    }
public List<DatoContacto>obtenerContacto(){
        List<DatoContacto> contacto = new ArrayList<>();
        contacto.add(new DatoContacto("Jair Salazar", "11400309", R.drawable.folklor_opt));
        return contacto;
    }

}