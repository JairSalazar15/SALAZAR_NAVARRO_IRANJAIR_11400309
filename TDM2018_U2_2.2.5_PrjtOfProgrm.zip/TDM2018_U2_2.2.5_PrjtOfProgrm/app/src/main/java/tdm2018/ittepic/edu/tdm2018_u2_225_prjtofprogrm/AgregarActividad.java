package tdm2018.ittepic.edu.tdm2018_u2_225_prjtofprogrm;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AgregarActividad extends AppCompatActivity {
    EditText actividad, etFechaIni, etFechaFin, credito;
    Integer idusuario;
    BDconect dbms;
    Button guardar, cancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_actividad);
        idusuario = DatosAlumno.idusuario;
        dbms = new BDconect(this, "BASE2", null,1);


        actividad=(EditText)findViewById(R.id.etactividad);
        etFechaIni=(EditText)findViewById(R.id.etfechainicio);
        etFechaFin=(EditText)findViewById(R.id.etFechafinal);
        credito=(EditText)findViewById(R.id.edtCreditos);
        guardar=(Button) findViewById(R.id.agregar);
        cancelar=(Button) findViewById(R.id.cancelar);
        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertarActividad();
                Intent ventana = new Intent(AgregarActividad.this,DatosAlumno.class);
                startActivity(ventana);
            }
        });
        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent ventana = new Intent(AgregarActividad.this,DatosAlumno.class);
                startActivity(ventana);
            }
        });
    }
    public void insertarActividad(){
        try {
            SQLiteDatabase tabla = dbms.getWritableDatabase();
            String SQL = "INSERT INTO ACTIVIDAD VALUES(NULL,IDALUMNO,'ACTIVIDAD1','FECHA_INI','FECHA_FIN','CREDITOS');";

            SQL = SQL.replace("IDALUMNO",idusuario.toString());
            SQL = SQL.replace("ACTIVIDAD1",actividad.getText().toString());
            SQL = SQL.replace("FECHA_INI",etFechaIni.getText().toString());
            SQL = SQL.replace("FECHA_FIN",etFechaFin.getText().toString());
            SQL = SQL.replace("CREDITOS",credito.getText().toString());


            tabla.execSQL(SQL);
            Toast.makeText(this, "¡Actividad agregada correctamente!", Toast.LENGTH_LONG).show();
            actividad.setText(""); etFechaIni.setText("");etFechaFin.setText("");credito.setText("");


        }catch (Exception e){
            mensajes("Atención",e.getMessage());
        }
    }

    private void mensajes(String titulo, String mensaje){
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setTitle(titulo).setMessage(mensaje);
        alerta.show();
    }
}
