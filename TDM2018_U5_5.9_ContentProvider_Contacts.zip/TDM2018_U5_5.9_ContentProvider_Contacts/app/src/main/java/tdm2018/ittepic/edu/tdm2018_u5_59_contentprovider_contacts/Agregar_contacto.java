package tdm2018.ittepic.edu.tdm2018_u5_59_contentprovider_contacts;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class Agregar_contacto extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_contacto);
    }
}
