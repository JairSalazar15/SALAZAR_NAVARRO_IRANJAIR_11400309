package tdm2018.ittepic.edu.tdm2018_u1_juegodetener;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button b1;
    TextView cont, aleatorio, vista;
    private EditText num1;
    Thread thread, thread1;
    boolean ejecutar,pausado;
    double con2=0;
    double con = 0;
    double numeroaleatorio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        vista=(TextView)findViewById(R.id.textView1);
        //num1 = (EditText) findViewById(R.id.editText);
       // aleatorio=(TextView)findViewById(R.id.textView);
        cont = findViewById(R.id.textView2);
        ejecutar = true;
        pausado = false;
        float l1 = 0.1f;
        float l2 = 3f;
        float generatedFloat = l2 + new Random().nextFloat() * (l1 - l2);
        numeroaleatorio = generatedFloat;
        DecimalFormat decimal = new DecimalFormat("###.#");
        final String numeroale=decimal.format(numeroaleatorio);
        cont.setText("Detener en: "+decimal.format(numeroaleatorio));
        con=numeroaleatorio;

        cont.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                ejecutar = true;
                vista.setText(numeroale);
                if (cont.getText().toString().equals(numeroale) ) {
                    Toast.makeText(MainActivity.this, "Ganaste!", Toast.LENGTH_SHORT).show();
                    ejecutar = false;

                } else {

                    if (pausado == false) {

                        try {
                            thread1 = new Thread() {
                                public void run() {
                                    //ejecuta en 2do plano
                                    while (ejecutar) {
                                        runOnUiThread(new Runnable() {
                                            //Ejecutar hilo en interfaz de usuario
                                            @Override
                                            public void run() {
                                                DecimalFormat df = new DecimalFormat();
                                                String twoDigitNum = df.format(con2);
                                                cont.setText(twoDigitNum);
                                            }
                                        });
                                        try {
                                            sleep(500);
                                        } catch (InterruptedException e) {
                                        }
                                        con2 += 0.10;
                                        if (con2 >= 5) {
                                            con2 = 1.00;
                                        }
                                    }
                                }
                            };
                            thread1.start();
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Error ya se ejecuto el hilo", Toast.LENGTH_SHORT).show();
                        }
                        pausado = true;

                    }else{
                        Toast.makeText(MainActivity.this, "Fallaste!", Toast.LENGTH_SHORT).show();
                        ejecutar=false;
                        finish();
                        startActivity(getIntent());
                    }

                }

            }

        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //pararJuego();
                pausado=true;
                cont.setText("Iniciar");
                finish();
            }
        });
    }

}
