package tdm.ittepic.edu.tpdm_54_sensores_contador_de_pasos;

/**
 * Created by Jair on 22/11/2017.
 */

public interface StepListener {
    public void step(long timeNs);
}
