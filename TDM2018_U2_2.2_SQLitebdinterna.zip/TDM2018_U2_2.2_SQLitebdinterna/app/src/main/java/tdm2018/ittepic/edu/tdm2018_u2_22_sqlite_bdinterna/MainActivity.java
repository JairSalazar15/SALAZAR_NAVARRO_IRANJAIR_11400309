package tdm2018.ittepic.edu.tdm2018_u2_22_sqlite_bdinterna;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    public static int variable;
    SQLite dbms;
    String[] arreglo;
    ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dbms = new SQLite(this, "BASE2", null,1);
        lista = (ListView)findViewById(R.id.datos);


        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                variable = position;
                Intent ventanaEstudiante = new Intent(MainActivity.this,Actualizar.class);
                startActivity(ventanaEstudiante);
            }
        });
        cargarConceptos();
    }

    public void cargarConceptos(){
        SQLite baseHelper = new SQLite(this,"BASE2",null,1);
        SQLiteDatabase db = baseHelper.getReadableDatabase();
        if (db!=null){
            Cursor c = db.rawQuery("SELECT * FROM USUARIO ORDER BY NOMBRE ASC", null);
            int cantidad = c.getCount();
            int i=0;

            arreglo =  new String[cantidad];
            if (c.moveToFirst()){
                do {
                    String linea =c.getString(1)+" \n - Correo: "+c.getString(2)+" \n - Telefono: "+c.getString(3);
                    arreglo[i] = linea;
                    i++;
                }while (c.moveToNext());
            }
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, arreglo);
            ListView lista = (ListView)findViewById(R.id.datos);
            lista.setAdapter(adapter);
        }
    }



    private void mensajes(String titulo, String mensaje){
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setTitle(titulo).setMessage(mensaje);
        alerta.show();
    }

    public boolean onCreateOptionsMenu(Menu m){
        MenuInflater constructor = getMenuInflater();
        constructor.inflate(R.menu.menu,m);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem mi) {
        switch (mi.getItemId()){
            case R.id.manipulacion:
                Intent Ventana = new Intent(MainActivity.this,Agregar.class);

                startActivity(Ventana);
                break;

            case R.id.salir:
                finish();
                break;
        }
        return true;
    }

}
